#include <windows.h>


BOOL WINAPI DllMain( HINSTANCE hInstance, DWORD dwReason, LPVOID lpv)
{
    return 1;
}