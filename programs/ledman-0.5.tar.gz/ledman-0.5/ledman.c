/*
 * ledman.c
 * 
 * Copyright (c) 1999 Pekka Riikonen, priikone@poseidon.pspt.fi.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 */

/*
 *
 * This code is Linux specific and thus is not portable.
 *
 * LedMan pins:
 *
 * Parallel port BASE+0
 *
 * D0	Unused in LedMan
 * D1	On/Off	1=high, 0=low, turns on/off all the leds
 * D2	Led 5	1=high, 0=low
 * D3	Led 4	1=high, 0=low
 * D4	Led 3	1=high, 0=low
 * D5	Led 2	1=high, 0=low
 * D6	Led 1	1=high, 0=low
 * D7	Timer	1=high, 0=low, repeating 1/0 scrolls the leds left
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/io.h>
#include <time.h>
#include <string.h>
#include <errno.h>
#include <asm/io.h>

#include "common.h"
#include "ledman.h"

unsigned short BASE;
unsigned int curspeed;
Font fonts[MAX_FONTS];
Buffer IB;

int main(int argc, char **argv)
{


	/* Initialise the LedMan */
	if (init_ledman(PAR1_BASE))
	    exit(1);

	process_ledman();

	/* Reset the LedMan */
	reset_ledman();

	return 0;
}

/* Initialises parport permissions. */

int init_ledman(unsigned short port)
{
	int ret;

	/* general inits */
	IB.i = 0;
	memset(IB.buf, 64, sizeof(IB.buf));
	cmd_speed(100);
	cmd_font("default.lf");

	ret = ioperm(port, 3, 1);
	if (ret == -1)
	    fprintf(stderr, strerror(errno));
	else
	    BASE = port;

	return ret;
}

/* Resets the parport permissions. */

int reset_ledman()
{
	int ret;

	ret = ioperm(BASE, 3, 0);
	if (ret == -1) {
	    fprintf(stderr, strerror(errno));
	    return -1;
	}

	return 0;
}

/* Do the thing. */

int process_ledman()
{
	int i;

	cmd_pause(1000);
	cmd_putchar('p', 23, 1);
	cmd_pause(3000);

	cmd_clear(0);
	cmd_scrolltext(".pe.", 0);
	cmd_pause(2000);
	cmd_putpixel(23, 1, 1);
	cmd_pause(2000);

	cmd_showpic("data/pic1.lp");
	cmd_clear(0);
	cmd_pause(2000);
	cmd_update();
	cmd_pause(5000);

	cmd_speed(50);
	cmd_clear(0);
	cmd_pause(1000);
	cmd_clear(0);
	cmd_update();
	cmd_pause(5000);
	cmd_scrolltext(" no joo testi", 0);
	cmd_pause(1000);
	cmd_clear(0);
	cmd_update();
	cmd_pause(5000);


	cmd_speed(30);
	cmd_scrollpic("data/pic1.lp", 0);
	cmd_clear(0);
	cmd_speed(30);
	cmd_clear(1);
	cmd_scrollpic("data/pic1.lp", 0);

	cmd_speed(10);
	cmd_scrolltext("Jee n�in sit� rollaillaan!", 0);
	cmd_speed(100);
	cmd_scrolltext("Jee n�in sit� rollaillaan!", 0);
	cmd_speed(50);

	cmd_showpic("data/pic1.lp");
	cmd_pause(500);
	cmd_clear(0);
	cmd_pause(2000);
	cmd_update();
	cmd_pause(5000);

	cmd_scrolltext("Jee n�in sit� rollaillaan!", 0);
	cmd_speed(30);
	cmd_scrolltext("Jee n�in sit� rollaillaan!", 0);
	cmd_speed(20);
	cmd_scrolltext("Jee n�in sit� rollaillaan!", 0);
	cmd_speed(70);
	cmd_scrolltext("Jee n�in sit� rollaillaan!", 0);


	cmd_speed(30);
	cmd_clear(0);
	cmd_showpic("data/pic1.lp");
	cmd_pause(1000);
	cmd_clear(0);
	cmd_speed(30);
	cmd_scrollpic("data/pic1.lp", 0);
	cmd_pause(1000);
	cmd_scrolltext("Jee n�in sit� rollaillaan!! :) T�m� rules!! :)", 0);
	cmd_pause(1000);
	cmd_clear(1);
	for (i = 500; i > 0; i -= 10) {
		cmd_clear(0);
		cmd_pause(i);
		cmd_clear(1);
		cmd_pause(i);
	}
	cmd_scrollpic("data/pic1.lp", 0);

	return 0;
}

/* Command FONT: Reads the LedMan fonts from a font file into 
the Font structure table, which is used as reference table when 
printing the fonts on the LedMan. */

int cmd_font(const char *filename)
{
	int i, k, filelen, begin, col, row;
	char *buffer, *cp;
	char line[1024];

	buffer = (char *)read_file(filename, &filelen);

	if (buffer == (char *)NULL)
		return -1;
	
	begin = col = 0;
	row = 1;
	i = 0;
        while((begin = ngets(line, sizeof(line), buffer, filelen, begin)) != EOF) {
		cp = line;

		if (check_line(cp))
			continue; 

		/* get the font */
		switch(row) {
			case 1:
				i++;
				fonts[i].font = cp[0];
				row++;
				break;
			default:
				for (k = 0, col = 0; k < 24; k++) {
					if (line[col] == '\n')
						break;
					fonts[i].bits[row - 2][col] = cp[col];
					col++;
				}
				row++;

				fonts[i].h = row - 2;
				fonts[i].w = col;

				if ((row - 2) == 5) 
					row = 1;

				break;
		}

	}

	free(buffer);

	return 0; 
}


/* Command SCROLLTEXT: Scrolls the text on the leds. */

int cmd_scrolltext(const unsigned char *text, int direction)
{
	int i, j, len;

	len = strlen(text);

	if (!direction) {		/* left */
		for (i = 0; i < len; i++)
			print_font(text[i]);
	} else {
		for (i = 0; i < len; i++) {

		}
	}

	return 0;
}

/* Command SPEED: Sets the scrolling speed. */

int cmd_speed(unsigned int speed)
{
	curspeed = speed;

	return 0;
}

/* Command CLEAR: Clears the screen. Either turns on or
off all the leds. Note this doesn't clear the inner buffer. */

int cmd_clear(int on)
{
	/* baah... tired of writing C so decided to
	do this easy part in assembler. :) Remember this
	is i386 specific code. */
	__asm__ __volatile__(
/*		"	pushl	%%ecx\n"	\
		"	pushl	%%edx\n"	\
		"	pushl	%%eax\n"	\
*/		"	testl 	$1, %0\n"	\
		"	jnz 	1f\n"		\
		"	movb 	$0x0, %%al\n"	\
		"	jmp	2f\n"		\
		"1:	movb 	$0x7e, %%al\n"	\
		"2:	movl	$0x18, %%ecx\n"	\
		"3:	outb 	%%al, %1\n"	\
		"	incb	%%al\n"		\
		"	outb	%%al, %1\n"	\
		"	decb	%%al\n"		\
		"	decl	%%ecx\n"	\
		"	jnz	3b\n"		\
/*		"	popl	%%eax\n"	\
		"	popl	%%edx\n"	\
		"	popl	%%ecx\n"	\
*/		: : "c" (on), "d" (BASE));

	return 0;
}

/* Command PAUSE: Pauses for a while. */

int cmd_pause(unsigned int pause)
{
	SLEEP(pause);

	return 0;
}

/* Command: PUTPIXEL: Puts pixel on the screen at x,y. This
actually puts the pixel into the inner buffer and then calls
UPDATE -command. Coordinates x=0, y=0 is up left corner. */

int cmd_putpixel(unsigned int x, unsigned int y, int on)
{
	char b0[8 + 1];
	unsigned int offset;

	b0[0] = '-';
	b0[1] = '-';
	b0[2] = '-';
	b0[3] = '-';
	b0[4] = '-';
	b0[5] = '-';
	b0[6] = '-';
	b0[7] = '-';

	if (y > 4)
		y = 4;
	if (y < 0)
		y = 0;

	if (x > 23)
		x = 23;
	if (x < 0)
		x = 0;

	/* pixel to y */
	b0[2 + (4 - y)] = '*';
	
	if ((IB.i + x) > 23)
		offset = (IB.i + x) - (23 + 1);
	else
		offset = (IB.i + x);

	/* pixel to x */
	IB.buf[offset] = IB.buf[offset] + byte(b0);

	if (on)
		cmd_update();

	return 0;
}

/* Command PUTCHAR: Puts a character (a font) on the screen at
x. x=0 puts the font to the very left side of the screen. Puts 
it to the inner buffer and calls UPDATE -command. Clears the 
area of the screen where the font is put. */

int cmd_putchar(unsigned int ch, unsigned int x, int on)
{
	unsigned int i, k, l, j, offset[6];
	char b0[8 + 1];

	b0[0] = '-';
	b0[1] = '*';
	b0[7] = '-';

	if (x > 24)
		x = 24;
	if (x < 0)
		x = 0;

	/* calculate the offsets */
	for (i = 0; i < 5; i++) {
		if ((IB.i + (x + i)) > 23)
			offset[i] = (IB.i + (x + i)) - (23 + 1);
		else
			offset[i] = (IB.i + (x + i));
	}

	/* find the font */
	k = 0;
	for (i = 0; i < MAX_FONTS; i++)
		if (ch == fonts[i].font) {
			k = 1;
			break;
		}
	if (!k)
		return -1;

	/* print the font */
	j = 5;
	if (x > 18)
		j = 24 - x;
	for (k = 0; k < j; k++) {
		for (l = 0; l < fonts[i].h; l++)
			b0[6 - l] = fonts[i].bits[l][k];

		IB.buf[offset[k]] = byte(b0);
	}

	if (on)
		cmd_update();

	return 0;
}

/* Command: UPDATE: updates the screen from inner buffer. */

int cmd_update()
{
	int i;

	cmd_clear(0);
	for (i = IB.i; i < 24; i++) {
		outb(IB.buf[i], BASE);
		outb(IB.buf[i] + 1, BASE);
	}

	for (i = 0; i < IB.i; i++) {
		outb(IB.buf[i], BASE);
		outb(IB.buf[i] + 1, BASE);
	}

	return 0;
}

/* Command: SHOWPIC: Shows a picture on the screen. */

int cmd_showpic(const char *filename)
{
	int i, k, filelen, begin, col, row;
	char *buffer, *cp;
	char line[1024];
	char b0[8 + 1];
	Picture pic;

	buffer = (char *)read_file(filename, &filelen);

	if (buffer == (char *)NULL)
		return -1;
	
	begin = col = row = 0;
        while((begin = ngets(line, sizeof(line), buffer, filelen, begin)) != EOF) {
		cp = line;

		if (check_line(cp))
			continue; 

		if (row >= 5)
			break;

		/* get the picture */
		for (i = 0, col = 0; i < 100; i++) {
			if (line[col] == '\n')
				break;
			pic.bits[row][col] = cp[col];
			col++;
		}
		row++;
	}

	pic.h = row;
	pic.w = col;

	b0[0] = '-';
	b0[1] = '*';
	b0[7] = '-';

	/* show the picture */
	for (k = 0; k < pic.w; k++) {
		for (i = 0; i < pic.h; i++) {
			b0[6 - i] = pic.bits[i][k];
		}

		SAVESCR(byte(b0));
		outb(byte(b0), BASE);
		outb(byte(b0) + 1, BASE);
	}

	free(buffer);
	
	return 0;
}

/* Command: SCROLLPIC: Scrolls the picture on the screen. */

int cmd_scrollpic(const char *filename, int direction)
{
	int i, k, filelen, begin, col, row;
	char *buffer, *cp;
	char line[1024];
	char b0[8 + 1];
	Picture pic;

	buffer = (char *)read_file(filename, &filelen);

	if (buffer == (char *)NULL)
		return -1;
	
	begin = col = row = 0;
        while((begin = ngets(line, sizeof(line), buffer, filelen, begin)) != EOF) {
		cp = line;

		if (check_line(cp))
			continue; 

		if (row >= 5)
			break;

		/* get the picture */
		for (i = 0, col = 0; i < 100; i++) {
			if (line[col] == '\n')
				break;
			pic.bits[row][col] = cp[col];
			col++;
		}
		row++;
	}

	pic.h = row;
	pic.w = col;

	b0[0] = '-';
	b0[1] = '*';
	b0[7] = '-';

	/* show the picture */
	for (k = 0; k < pic.w; k++) {
		for (i = 0; i < pic.h; i++)
			b0[6 - i] = pic.bits[i][k];

		SAVESCR(byte(b0));
		outb(byte(b0), BASE);
		SLEEP(curspeed);
		outb(byte(b0) + 1, BASE);
	}

	free(buffer);
	
	return 0;
}


/* Prints one character on the leds. */

void print_font(const unsigned char fnt)
{
	int i, k, l;
	char b0[8 + 1];

	b0[0] = '-';
	b0[1] = '*';
	b0[7] = '-';

	k = 0;
	for (i = 0; i < MAX_FONTS; i++)
		if (fnt == fonts[i].font) {
			k = 1;
			break;
		}
	if (!k)
		return;

	for (k = 0; k < fonts[i].w; k++) {
		for (l = 0; l < fonts[i].h; l++)
			b0[6 - l] = fonts[i].bits[l][k];

		SAVESCR(byte(b0));
		outb(byte(b0), BASE);
		SLEEP(curspeed);
		outb(byte(b0) + 1, BASE);
	}
}
