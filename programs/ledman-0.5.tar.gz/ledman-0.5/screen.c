/*
 * screen.c			Software Led screen.
 * 
 * Copyright (c) 1999 Pekka Riikonen, priikone@poseidon.pspt.fi.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 */

/*
 * This is a software emulation of the LedMan led device. This
 * makes it possible to test ledman without the actual device.
 */

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <termcap.h>
#include <curses.h>

#include "common.h"
#include "ledman.h"
#include "screen.h"

unsigned int tlines;
unsigned int tcols;

/* Initialises the termcap and curses. */

void screen_init()
{
	char trm[1024], *ptr;
	char *term;
	char *tmp;
 
	ptr = trm;
 
	if ((term = getenv("TERM")) == (char *)NULL) {
		fprintf(stderr, "TERM environment variable is not set.\n");
		exit(1);
        }
	if (tgetent(trm, term) < 1) {
		fprintf(stderr, "Cannot find termcap entry for '%s'.\n", term);
		exit(1);
	}
 
	/* get the screens lines and columns */
	if ((tlines = tgetnum("li")) == (int)NULL) {
		if ((tmp = getenv("LINES")) == (char *)NULL)
			tlines = 24;
		else
			tlines = atoi(tmp);
	}
	if ((tcols = tgetnum("co")) == (int)NULL) {
		if ((tmp = getenv("COLUMNS")) == (char *)NULL)
			tcols = 80;
		else
			tcols = atoi(tmp);
	}

	/* clear to end of line */
	if ((CE = tgetstr("ce", &ptr)) == (char *)NULL) {
		fprintf(stderr, "Your terminal doesn't support clearing line.");
		exit(1);
	}

        /* init ncurses */
        initscr();
        cbreak();
        noecho();
        endwin();
}
