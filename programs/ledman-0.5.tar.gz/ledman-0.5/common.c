/*
 * common.c				Common functions
 * 
 * Copyright (c) 1998, 1999 Pekka Riikonen, priikone@poseidon.pspt.fi.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 */

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>

#include "common.h"

/* power of 2's for bit conversion */ 
static unsigned int POW[8] =
	{1, 2, 4, 8, 16, 32, 64, 128}; 

/* Reads a line from the buffer. Stop reading if newline or EOF
occurs. This function doesn't remove the newline sign from the
destination buffer. This function replaces gets(). */

int ngets(char *dest, int destlen, const char *src, int srclen, int begin)
{
	static int start = 0;
	int i;

	memset(dest, 0, destlen);

	if (begin != start)
	    start = 0;

	i = 0;
	for (;start <= srclen; i++, start++) {
	    if (i > destlen)
		return -1;

	    dest[i] = src[start];

	    if (dest[i] == EOF) 
		return EOF;

	    if (dest[i] == '\n') 
		break;
	}
	start++;

	return start;
}

/* Checks the line. Returns -1 if illegal characters were 
found, 0 if the line is ok. */

int check_line(char *buf)
{

        if (strchr(buf, '\t')) return -1;
        if (strchr(buf, '\r')) return -1;
        if (strchr(buf, '\a')) return -1;
        if (strchr(buf, '\b')) return -1;
        if (strchr(buf, '\f')) return -1;

	if (buf[0] == '\n')
	    return -1;

        return 0;
}

/* Reads the file into the buffer and returns a pointer to it. */

char *read_file(const char *filename, int *len)
{
	int fd;
	char *buffer;
	int filelen;

	if ((fd = open(filename, O_RDONLY)) < 0) {
	    fprintf(stderr, strerror(errno));
	    return (char *)NULL;
	}

        filelen = lseek(fd, (off_t)0L, SEEK_END);
        lseek(fd, (off_t)0L, SEEK_SET);

	buffer = (char *)malloc(filelen + 1);

        if ((read(fd, buffer, filelen)) == -1) {
            memset(buffer, 0, sizeof(buffer));
            close(fd);
	    fprintf(stderr, strerror(errno));
	    return (char *)NULL;
        }
        close(fd);
	buffer[filelen] = EOF;

	*len = filelen;
	return buffer;
}

/* Converts bits to byte. In fact, the bits are not represented 
as '0' and '1', but as '-' and '*', as in ledman script files. 
Returns the byte. */
 
char byte(char *bits) 
{
        int by;
        int i;

        by = 0;
        for (i = 0; i < 8; i++)
                if (bits[i] == '*')
                        by += POW[7 - i];

        return by;
}
