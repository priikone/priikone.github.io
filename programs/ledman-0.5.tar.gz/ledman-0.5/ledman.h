/*
 * ledman.h
 * 
 * Copyright (c) 1999 Pekka Riikonen, priikone@poseidon.pspt.fi.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 */

#ifndef _LEDMAN_H
#define _LEDMAN_H

/* Parallel port I/O-bases */ 
#define PAR0_BASE	0x3bc	/* par0 */
#define PAR1_BASE	0x378	/* par1 */
#define PAR2_BASE	0x278	/* par2 */
 
/* Max fonts in ledman */
#define MAX_FONTS       (256 / 2) - 32   

/* Ledman's inner buffer. Always holds the contents
of one ledman screen (5x24 pixels). */
typedef struct {
	char buf[25];			/* bytes */
	unsigned short i;		/* offset */
} Buffer;

/* Font structure. A font can be maximum of 24 pixels
wide and 5 pixes high. */
typedef struct {
	char bits[5 + 1][24 + 1];	/* bits int the font */
	unsigned short w;		/* width */
	unsigned short h;		/* height */
	unsigned char font;		/* actual character */
} Font;

/* Picture structure. A picture can be maximum of 100 pixels
wide and 5 pixed high. */
typedef struct {
	char bits[5 + 1][100 + 1];	/* bits in the picture */
	unsigned short w;		/* width */
	unsigned short h;		/* height */
} Picture;

/* Sleep macro. This sucks... */
#define SLEEP(x)	({int xx; \
			for (xx=0; xx < x * 100000; xx++) \
			__asm__ __volatile__("nop");} )

/* Saves the current screen.*/
#define SAVESCR(x)	({if (IB.i >= 24) IB.i = 0; \
			IB.buf[IB.i++] = (x);})

int init_ledman(unsigned short port); 
int reset_ledman(); 
int process_ledman();
int cmd_font(const char *filename);
int cmd_scrolltext(const unsigned char *text, int direction); 
int cmd_speed(unsigned int speed);
int cmd_clear(int on);
int cmd_pause(unsigned int pause);
int cmd_putpixel(unsigned int x, unsigned int y, int on);
int cmd_putchar(unsigned int ch, unsigned int x, int on);
int cmd_update();
int cmd_showpic(const char *filename);
int cmd_scrollpic(const char *filename, int direction);
void print_font(const unsigned char fnt);


#endif
